/* ============================== typing animation ============================ */
var typed = new Typed(".typing",{
    strings:[ "Full Stack Web Developer", " App Developer", " Marketing Specialist"],
    typeSpeed:120,
    BackSpeed:80,
    loop:true
})
/* ============================== Aside ============================ */
const nav = document.querySelector(".nav"),
      navList = nav.querySelectorAll("li"),
      totalNavList = navList.length,
      allSection = document.querySelectorAll(".section"),
      totalSection = allSection.length;
      for(let i=0; i<totalNavList; i++)
      {
          const a = navList[i].querySelector("a");
          a.addEventListener("click", function()
          {
              removeBackSection();
              for(let j=0; j<totalNavList; j++)
              {
                  if(navList[j].querySelector("a").classList.contains("active"))
                  {
                      addBackSection(j);
                     // allSection[j].classList.add("back-section");
                  }
                  navList[j].querySelector("a").classList.remove("active");
              }
              this.classList.add("active")
              showSection(this);
              if(window.innerWidth < 1200)
              {
                  asideSectionTogglerBtn();
              }
          })
      }
      function removeBackSection()
      {
        for(let i=0; i<totalSection; i++)
        {
            allSection[i].classList.remove("back-section");
        }   
      }
      function addBackSection(num)
      {
        allSection[num].classList.add("back-section");
      }
      function showSection(element)
      {
          for(let i=0; i<totalSection; i++)
          {
              allSection[i].classList.remove("active");
          }
          const target = element.getAttribute("href").split("#")[1];
          document.querySelector("#" + target).classList.add("active")
      }
      function updateNav(element)
      {
          for(let i=0; i<totalNavList; i++)
          {
              navList[i].querySelector("a").classList.remove("active");
              const target = element.getAttribute("href").split("#")[1];
              if(target === navList[i].querySelector("a").getAttribute("href").split("#")[1])
              {
                navList[i].querySelector("a").classList.add("active");
              }
          }
      }
      document.querySelector(".hire-me").addEventListener("click", function()
      {
          const sectionIndex = this.getAttribute("data-section-index");
          console.log(sectionIndex);
          showSection(this);
          updateNav(this);
          removeBackSection();
          addBackSection(sectionIndex);
      })
      const navTogglerBtn = document.querySelector(".nav-toggler"),
            aside = document.querySelector(".aside");
            navTogglerBtn.addEventListener("click", () => 
            {
                asideSectionTogglerBtn();
            })
            function asideSectionTogglerBtn()
            {
                aside.classList.toggle("open");
                navTogglerBtn.classList.toggle("open");
                for(let i=0; i<totalSection; i++ )
                {
                    allSection[i].classList.toggle("open");
                }
            }
//Send Email
            const sendButton = document.querySelector('#sendM');

            sendButton.addEventListener('click', (e) => {
              e.preventDefault();
              const name = document.querySelector('#name').value;
              const email = document.querySelector('#email').value;
              const subject = document.querySelector('#subject').value;
              const message = document.querySelector('#message').value;
              const data = {
                name,
                email,
                subject,
                message
              };
              const spinnerTarget = document.getElementById('spinner');
              const spinner = new Spinner().spin(spinnerTarget);
              fetch('/send-email', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
              })
              .then(response => response.json())
              .then(data => {
                console.log(data);
                alert(data.message);
                document.querySelector('#name').value = '';
                document.querySelector('#email').value = '';
                document.querySelector('#subject').value = '';
                document.querySelector('#message').value = '';
              })
              .catch(error => {
                console.error(error);
                alert('Error al enviar el mensaje');
              })
              .finally(() => {
                spinner.stop();
              });
              
            });
         
////Change Language
    $(document).ready(function(){
      let savedLang = localStorage.getItem('lang');
      let browserLang = navigator.language || navigator.userLanguage;
      let defaultLang = savedLang || browserLang.split('-')[0] || 'en';

      $.getJSON('js/lang.json', function(json){
        localStorage.setItem('lang', defaultLang);
        updateLanguage(defaultLang, json);
        $('.translate').click(function(){
          let lang = $(this).attr("id");
          updateLanguage(lang, json);
          localStorage.setItem('lang', lang);
        });
      });
    });

    function updateLanguage(lang, json){
      $('.lang').each(function(index, value){
        $(this).text(json[lang][$(this).attr('key')]);
      });
    }
